use dfs_poc::live::mount_cache::{Limits as CacheLimits, MountCache};
use dfs_poc::{
    client::Client,
    engine::{Engine, Limits, token_hash},
    model::*,
    rpc::Service,
    wire::dfs_server::DfsServer,
};
use std::sync::{Arc, atomic::Ordering};

struct Fixture {
    client: Client,
    endpoint: String,
    server: tokio::task::JoinHandle<()>,
    _directory: tempfile::TempDir,
}
impl Drop for Fixture {
    fn drop(&mut self) {
        self.server.abort();
    }
}
impl Fixture {
    async fn new() -> anyhow::Result<Self> {
        let directory = tempfile::tempdir()?;
        let credentials = ["admin", "writer"]
            .into_iter()
            .map(|subject| Credential {
                token_hash: token_hash(subject),
                tenant: "tenant".into(),
                issuer: "test".into(),
                subject: subject.into(),
                principal: subject.into(),
                admin: subject == "admin",
                scope: None,
                expires_ms: now_ms() + 3_600_000,
            })
            .collect();
        let engine = Arc::new(Engine::open(
            directory.path().join("db"),
            credentials,
            Limits::default(),
        )?);
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await?;
        let endpoint = format!("http://{}", listener.local_addr()?);
        let server = tokio::spawn(async move {
            tonic::transport::Server::builder()
                .add_service(DfsServer::new(Service::new(engine)))
                .serve_with_incoming(tokio_stream::wrappers::TcpListenerStream::new(listener))
                .await
                .unwrap();
        });
        let client = Client::connect(&endpoint, "admin", None).await?;
        Ok(Self {
            client,
            endpoint,
            server,
            _directory: directory,
        })
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn buffered_creates_coalesce_and_sync_preserves_all_files() -> anyhow::Result<()> {
    let f = Fixture::new().await?;
    let cache = MountCache::new(f.client.clone(), CacheLimits::default())?;
    let root = f.client.view().await?.nodes[0].node.id.clone();
    cache.validation().await?;
    let before = f.client.counters.mutation_calls.load(Ordering::Relaxed);
    let mut ids = Vec::new();
    for n in 0..32 {
        let node = cache
            .mutate(Mutation::Create {
                parent: root.clone(),
                name: format!("file-{n}"),
                kind: Kind::File,
                mode: 0o600,
            })
            .await?
            .node
            .unwrap();
        let mut handle = cache.open_file(&node.id, libc::O_RDWR).await?;
        cache.write_file(&mut handle, 0, vec![n; 4096]).await?;
        cache
            .setattr_file(&mut handle, Some(0o640), Some(1234))
            .await?;
        assert_eq!(
            cache.try_read_file(&mut handle, 0, 4096)?.unwrap(),
            vec![n; 4096]
        );
        cache.flush_file(&mut handle).await?;
        cache.close_file(handle).await?;
        ids.push(node.id);
    }
    assert_eq!(
        f.client.counters.mutation_calls.load(Ordering::Relaxed),
        before
    );
    assert_eq!(f.client.view().await?.nodes.len(), 1);
    cache.finish_buffer().await?;
    assert_eq!(
        f.client.counters.mutation_calls.load(Ordering::Relaxed) - before,
        1
    );
    let view = f.client.view().await?;
    assert_eq!(view.nodes.len(), 33);
    for (n, id) in ids.iter().enumerate() {
        let item = view.nodes.iter().find(|item| &item.node.id == id).unwrap();
        assert_eq!(
            (item.node.mode, item.node.mtime_ms, item.node.size),
            (0o640, 1234, 4096)
        );
        let mut handle = cache.open_file(id, libc::O_RDONLY).await?;
        assert_eq!(
            cache.read_file(&mut handle, 0, 4096).await?.bytes,
            vec![n as u8; 4096]
        );
    }
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn file_batch_is_atomic_fenced_and_idempotent() -> anyhow::Result<()> {
    let f = Fixture::new().await?;
    let root = f.client.view().await?.nodes[0].node.id.clone();
    let file = |name: &str| FileUpdate {
        node: Node {
            id: id(),
            parent: Some(root.clone()),
            name: name.into(),
            kind: Kind::File,
            version: id(),
            entry_token: id(),
            size: 4,
            mode: 0o600,
            mtime_ms: 9,
            unlinked: false,
        },
        base: None,
        data: b"data".to_vec(),
    };
    let existing = file("exists");
    let mutation = Mutation::PutFiles {
        files: vec![file("first"), existing.clone()],
    };
    let identity = f.client.prepare_publication(&mutation)?;
    let published = f.client.publish(identity.clone(), mutation.clone()).await?;
    let repeated = f.client.publish(identity, mutation).await?;
    assert_eq!(published.outcome.head, repeated.outcome.head);
    let collision = Mutation::PutFiles {
        files: vec![file("absent"), file("exists")],
    };
    assert_eq!(
        f.client.mutate(collision).await.unwrap_err().code,
        libc::EEXIST
    );
    assert_eq!(f.client.view().await?.nodes.len(), 3);
    let mut replacement = existing.clone();
    replacement.base = Some(existing.node.version.clone());
    replacement.node.version = id();
    replacement.data = b"next".to_vec();
    f.client
        .mutate(Mutation::PutFiles {
            files: vec![replacement.clone()],
        })
        .await?;
    replacement.node.version = id();
    assert_eq!(
        f.client
            .mutate(Mutation::PutFiles {
                files: vec![file("rolled-back"), replacement]
            })
            .await
            .unwrap_err()
            .code,
        libc::ESTALE
    );
    assert_eq!(f.client.view().await?.nodes.len(), 3);
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn buffered_revocation_is_deferred_and_retained() -> anyhow::Result<()> {
    let f = Fixture::new().await?;
    let root = f.client.view().await?.nodes[0].node.id.clone();
    f.client
        .mutate(Mutation::Grant {
            node: root.clone(),
            subject: "writer".into(),
            verbs: CREATE | READ | WRITE | LIST | TRAVERSE,
        })
        .await?;
    let writer = Client::connect(&f.endpoint, "writer", None).await?;
    let cache = MountCache::new(writer, CacheLimits::default())?;
    let node = cache
        .mutate(Mutation::Create {
            parent: root.clone(),
            name: "revoked".into(),
            kind: Kind::File,
            mode: 0o600,
        })
        .await?
        .node
        .unwrap();
    let mut handle = cache.open_file(&node.id, libc::O_RDWR).await?;
    cache
        .write_file(&mut handle, 0, b"pending".to_vec())
        .await?;
    f.client
        .mutate(Mutation::Grant {
            node: root,
            subject: "writer".into(),
            verbs: 0,
        })
        .await?;
    tokio::time::sleep(std::time::Duration::from_millis(520)).await;
    assert_eq!(
        cache
            .write_file(&mut handle, 0, b"expired".to_vec())
            .await
            .unwrap_err()
            .code,
        libc::EACCES
    );
    cache.close_file(handle).await?;
    assert_eq!(cache.finish_buffer().await.unwrap_err().code, libc::EACCES);
    assert_eq!(cache.finish_buffer().await.unwrap_err().code, libc::EACCES);
    assert_eq!(f.client.view().await?.nodes.len(), 1);
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn graceful_unmount_drains_unpublished_files() -> anyhow::Result<()> {
    let f = Fixture::new().await?;
    let runtime = tokio::runtime::Handle::current();
    let client = f.client.clone();
    tokio::task::spawn_blocking(move || -> anyhow::Result<()> {
        let directory = tempfile::tempdir()?;
        let mount = dfs_poc::live::mount::Mount::new(client, runtime, CacheLimits::default())?;
        let session = mount.spawn(
            directory.path(),
            &[fuser::MountOption::FSName("buffer-test".into())],
        )?;
        for n in 0..16 {
            std::fs::write(
                directory.path().join(format!("files/file-{n}")),
                vec![n as u8; 4096],
            )?;
        }
        let result = std::process::Command::new("fusermount3")
            .args(["-u", "--"])
            .arg(directory.path())
            .output()?;
        anyhow::ensure!(
            result.status.success(),
            "{}",
            String::from_utf8_lossy(&result.stderr)
        );
        session.shutdown()?;
        Ok(())
    })
    .await??;
    let view = f.client.view().await?;
    assert_eq!(view.nodes.len(), 17);
    for n in 0..16 {
        let node = &view
            .nodes
            .iter()
            .find(|item| item.node.name == format!("file-{n}"))
            .unwrap()
            .node;
        let Reply::Data(bytes) = f
            .client
            .call(Call::Read {
                node: node.id.clone(),
                version: None,
                offset: 0,
                size: 4096,
                handle: None,
            })
            .await?
        else {
            anyhow::bail!("read reply");
        };
        assert_eq!(bytes, vec![n as u8; 4096]);
    }
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn incremental_refresh_handles_more_than_128_changes() -> anyhow::Result<()> {
    let f = Fixture::new().await?;
    let view = f.client.view().await?;
    let root = view.nodes[0].node.id.clone();
    for batch in 0..3 {
        let files = (0..64)
            .map(|n| FileUpdate {
                node: Node {
                    id: id(),
                    parent: Some(root.clone()),
                    name: format!("delta-{batch}-{n}"),
                    kind: Kind::File,
                    version: id(),
                    entry_token: id(),
                    size: 0,
                    mode: 0o600,
                    mtime_ms: 0,
                    unlinked: false,
                },
                base: None,
                data: Vec::new(),
            })
            .collect();
        f.client.mutate(Mutation::PutFiles { files }).await?;
    }
    let other = Client::connect(&f.endpoint, "admin", None).await?;
    let Reply::Delta(delta) = other
        .call(Call::Changes {
            cursor: Cursor {
                incarnation: view.incarnation,
                head: view.head,
            },
        })
        .await?
    else {
        anyhow::bail!("delta reply");
    };
    assert!(!delta.reset);
    assert_eq!(delta.head, view.head + 192);
    assert_eq!(delta.upserts.len(), 193);
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn capacity_flush_keeps_current_file_buffered() -> anyhow::Result<()> {
    let f = Fixture::new().await?;
    let cache = MountCache::new(f.client.clone(), CacheLimits::default())?;
    let root = f.client.view().await?.nodes[0].node.id.clone();
    cache.validation().await?;
    let before = f.client.counters.mutation_calls.load(Ordering::Relaxed);
    let mut nodes = Vec::new();
    for n in 0..2 {
        let node = cache
            .mutate(Mutation::Create {
                parent: root.clone(),
                name: format!("capacity-{n}"),
                kind: Kind::File,
                mode: 0o600,
            })
            .await?
            .node
            .unwrap();
        let mut handle = cache.open_file(&node.id, libc::O_RDWR).await?;
        cache.write_file(&mut handle, 0, vec![n; 300 << 10]).await?;
        cache
            .write_file(&mut handle, 300 << 10, vec![n; 300 << 10])
            .await?;
        cache
            .setattr_file(&mut handle, Some(0o640), Some(1234))
            .await?;
        cache.flush_file(&mut handle).await?;
        cache.close_file(handle).await?;
        nodes.push(node.id);
    }
    assert_eq!(
        f.client.counters.mutation_calls.load(Ordering::Relaxed),
        before + 1
    );
    let view = f.client.view().await?;
    assert_eq!(view.nodes.len(), 2);
    assert!(view.nodes.iter().any(|item| item.node.id == nodes[0]));
    assert!(!view.nodes.iter().any(|item| item.node.id == nodes[1]));
    cache.finish_buffer().await?;
    assert_eq!(
        f.client.counters.mutation_calls.load(Ordering::Relaxed),
        before + 2
    );
    for (n, node) in nodes.into_iter().enumerate() {
        let mut handle = cache.open_file(&node, libc::O_RDONLY).await?;
        assert_eq!(
            cache.read_file(&mut handle, 0, 600 << 10).await?.bytes,
            vec![n as u8; 600 << 10]
        );
        assert_eq!(handle.node().mode, 0o640);
        assert_eq!(handle.node().mtime_ms, 1234);
        cache.close_file(handle).await?;
    }
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn acknowledged_directory_overlay_preserves_unseen_changes() -> anyhow::Result<()> {
    let f = Fixture::new().await?;
    let cache = MountCache::new(f.client.clone(), CacheLimits::default())?;
    let root = f.client.view().await?.nodes[0].node.id.clone();
    cache.validation().await?;
    let before = f.client.counters.head_calls.load(Ordering::Relaxed);
    f.client
        .mutate(Mutation::Create {
            parent: root.clone(),
            name: "external".into(),
            kind: Kind::Directory,
            mode: 0o700,
        })
        .await?;
    let node = cache
        .mutate(Mutation::Create {
            parent: root.clone(),
            name: "local".into(),
            kind: Kind::Directory,
            mode: 0o700,
        })
        .await?
        .node
        .unwrap();
    assert_eq!(
        cache.lookup(Some(&root), "local").await?.item.node.id,
        node.id
    );
    assert_eq!(f.client.counters.head_calls.load(Ordering::Relaxed), before);
    cache.invalidate().await;
    assert_eq!(
        cache.lookup(Some(&root), "external").await?.item.node.name,
        "external"
    );
    assert_eq!(
        cache.lookup(Some(&root), "local").await?.item.node.id,
        node.id
    );
    assert_eq!(
        f.client.counters.head_calls.load(Ordering::Relaxed),
        before + 1
    );
    cache.finish_buffer().await?;
    Ok(())
}
